Twitter.configure do |config|
  config.consumer_key = 'znZPrbyhUOBt8cztCbIc6A'
  config.consumer_secret = 'VmLGTKW39Imnmmo3HZYkZEk9cLU8d9LDWOKRQpBXMY'
  config.oauth_token = "246270916-7Z3leKVOoEwKUBxAWtH0C5vwLX7QWgsvOd8QqbHT"
  config.oauth_token_secret = "3YzLOESUA73C7blbCVOBJWIU335WQoK5Qlb17ksi1w"
end
